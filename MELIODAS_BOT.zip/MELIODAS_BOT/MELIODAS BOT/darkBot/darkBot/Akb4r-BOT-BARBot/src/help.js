const help = (prefix) => {
	return `BARXNL-BOT
	
	                
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}creator*
┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker* [foto]
┣➥ *${prefix}stickergif* [foto]
┣➥ *${prefix}sticker nobg 
┣➥ *${prefix}thunder* [teks]
┣➥ *${prefix}tsticker* [teks/url]
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts* [teks]
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *${prefix}toimg*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}wait* [foto]
┣➥ *${prefix}simi
┣➥ *${prefix}simih*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}getpp*
┣➥ *${prefix}tagall*
┣➥ *${prefix}linkgroup
┣➥ *${prefix}gprofile*
┣➥ *${prefix}setprefix
┣➥ *${prefix}welcome*
┣➥ *${prefix}left*
┃
┣━━━━°❀ ❬ 𝙎𝙊𝙐𝙉𝘿 ❭ ❀°━━━━━⊱
┃
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃Thanks To : Aris187 ID
┃Follow Ig : @sadboy_ig
┃Owner     : Muhammad Akbar
┃Follow Ig : @barxnl
┃
┃And Thanks To🔥
┃MhankBarBar
┃FdciAbdul
┣━━━━━━━━━━━━━━━━━━━━
┃ 🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

