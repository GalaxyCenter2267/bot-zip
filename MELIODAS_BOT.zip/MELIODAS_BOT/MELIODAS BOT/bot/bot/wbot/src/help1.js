const help1 = (prefix) => {

	return `
╔══✪〘 INFO 〙✪══
║
╠➥ 𝐃𝐀𝐑𝐊 𝐁𝐎𝐓
╠➥ *3.0*
╠➥ 𝐃𝐎𝐍𝐎:  ⃬⃗𝐷𝐴𝑅𝐾⃖  ☔
╠➥ *wa.me/+5517991134416*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MENU1 〙✪══
║
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
║
╠══✪〘 *FIM* 〙✪══

════════════════════
*DARK YT* 🤗
*Digite ${prefix}dono para mais info*
════════════════════`
}
exports.help1 = help1

